function CustomerCare(){
    return(
        <div>
        <h4>Message from Customers</h4>
        </div>
    )
}
export default CustomerCare;