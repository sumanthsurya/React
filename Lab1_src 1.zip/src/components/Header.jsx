import "../assets/css/Index.css"
import React from 'react'

function Header() {
    return (
        <div>
            <header class="header">
                <div class="wrapper">
                    <h1>HOUSE RENTAL SYSTEM</h1>
                </div>
            </header>
        </div>
    )
}

export default Header