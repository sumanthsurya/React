import './App.css';
import SignupForm from './components/SignupForm';

function App() {
  return (
    <SignupForm />
  );
}

export default App;
